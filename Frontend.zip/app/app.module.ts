import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavigationComponent } from './parts/navigation/navigation.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CreateProductComponent } from './pages/create-product/create-product.component';
import {MatButtonModule} from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { ProductListComponent } from './pages/product-list/product-list.component';
import { ProductDetailsComponent } from './pages/product-details/product-details.component';
import { ProductUpdateComponent } from './pages/product-update/product-update.component';
import { CategoryListComponent } from './pages/category-list/category-list.component';
import { CustomerListComponent } from './pages/customer-list/customer-list.component';
import { HomeComponent } from './pages/home/home.component';
import { SearchComponent } from './pages/search/search.component';
import { CartComponent } from './pages/cart/cart.component';
import { AdminComponent } from './pages/admin/admin.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { UserOrderComponent } from './pages/user-order/user-order.component';
import { OrderlistComponent } from './pages/orderlist/orderlist.component';






@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    CreateProductComponent,
    LoginComponent,
    RegisterComponent,
    ProductListComponent,
    ProductDetailsComponent,
    ProductUpdateComponent,
    CategoryListComponent,
    CustomerListComponent,
    HomeComponent,
    SearchComponent,
    CartComponent,
    AdminComponent,
    ProfileComponent,
    UserOrderComponent,
    OrderlistComponent


  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,FormsModule,MatButtonModule, BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
