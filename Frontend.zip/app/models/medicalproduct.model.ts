import { ProductCategory } from "./category";

export class MedicalProduct {
  public id : number;
  public name: string;
  public unitPrice: number;
  public description: string;
  public imageUrl: string;
  public mfgDate :Date;
  public expDate: Date;
  public company : string;
  public category :ProductCategory;
  }