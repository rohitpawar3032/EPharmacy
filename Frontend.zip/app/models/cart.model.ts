import { MedicalProduct } from "./medicalproduct.model";


export class Cart {
  public item : MedicalProduct;
  public amount: number;
  constructor(item: MedicalProduct, amount: number){
    this.item = item;
    this.amount = amount;
  }
}
