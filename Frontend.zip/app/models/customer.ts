export class Customer {
    public customerId : number;
    public firstName: string;
    public lastName: string;
    public email: string;
    public password: string;
    public isPharmacyManager:boolean;
    public mobileNo : string;
    public address: string;
    public city: string;
    public state: string;
    }