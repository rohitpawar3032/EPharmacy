export class ProductCategory {
    public categoryId : number;
    public categoryType: string;
    }