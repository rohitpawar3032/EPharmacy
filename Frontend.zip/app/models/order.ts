import { Customer } from "./customer";

export class Order {
    public orderId : number;
    public OrderPrice: number;
    public shipmentId: number;
    public paymentId: number;
    public paymentType: string;
    public customer:Customer;
    }