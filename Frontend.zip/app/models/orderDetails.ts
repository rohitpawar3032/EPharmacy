import { CustomerService } from "../Services/customer.service";
import { Customer } from "./customer";
import { MedicalProduct } from "./medicalproduct.model";

export class OrderDetails {
    public detailsId : number;
    public totalPrice: number;
    public billDate: Date;
    public orderQuantity: number;
    public product:MedicalProduct;
    public customer:Customer;
    }