import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './pages/admin/admin.component';
import { CartComponent } from './pages/cart/cart.component';
import { CategoryListComponent } from './pages/category-list/category-list.component';
import { CreateProductComponent } from './pages/create-product/create-product.component';
import { CustomerListComponent } from './pages/customer-list/customer-list.component';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { OrderlistComponent } from './pages/orderlist/orderlist.component';
import { ProductDetailsComponent } from './pages/product-details/product-details.component';
import { ProductListComponent } from './pages/product-list/product-list.component';
import { ProductUpdateComponent } from './pages/product-update/product-update.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { RegisterComponent } from './pages/register/register.component';
import { SearchComponent } from './pages/search/search.component';
import { UserOrderComponent } from './pages/user-order/user-order.component';

const routes: Routes = [

  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'medicalitems', component: ProductListComponent },
  { path: 'add', component: CreateProductComponent },
  { path: 'login', component: LoginComponent},
  { path: 'register', component: RegisterComponent},
  { path: 'details/:id', component: ProductDetailsComponent },
  { path: 'update/:id', component: ProductUpdateComponent },
  { path: 'categories', component: CategoryListComponent },
  {path: 'home', component: HomeComponent},
  {path: 'cart', component: CartComponent},
  {path: 'admin', component: AdminComponent},
  {path: 'customer', component: CustomerListComponent},
  {path: 'search', component: SearchComponent},
  {path: 'profile', component: ProfileComponent},
  {path: 'userorder', component: UserOrderComponent},
  {path: 'orderlist', component: OrderlistComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
