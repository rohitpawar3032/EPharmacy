import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';


@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {
  custlogin:boolean=false
  search:string=""
username:string=sessionStorage.getItem("firstName");
adminlogin:boolean=false


  constructor(private router: Router,
    private authService: AuthService) { }

  ngOnInit(): void {
   
      this.custlogin=JSON.parse(sessionStorage.getItem("custId"));
      this.adminlogin=JSON.parse(sessionStorage.getItem("admId"));
  }
 onLogout()
   {
     sessionStorage.removeItem('custId');
   }
   onSearch()
   {
     localStorage.setItem("search",this.search)
 
     this.router.navigate(['/search'])
   }

}
