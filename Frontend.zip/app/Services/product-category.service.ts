import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ProductCategory } from '../models/category';

@Injectable({
  providedIn: 'root'
})
export class ProductCategoryService {

  private baseUrl = 'http://localhost:8181';

  constructor(private http: HttpClient) { }

  getCategory(id: number): Observable<any> {

    console.log(".....");
    return this.http.get(this.baseUrl+'/categories/'+id);
  }

  createCategory(category: Object): Observable<Object> {
    console.log(category);
        return this.http.post(this.baseUrl+'/categories/', category);
  }

  updateCategory(category: ProductCategory): Observable<Object> {
    console.log(category.categoryId);
    return this.http.put(this.baseUrl+'/categories/'+category.categoryId,category);
  }

  deleteCategory(id: number): Observable<any> {
    console.log(".....");
    console.log(this.baseUrl+'/categories/'+id)
    return this.http.delete<boolean>(this.baseUrl+'/categories/'+id);
  }

  getCategoryList(): Observable<any> {
    console.log(this.baseUrl+'/categories/');
    return this.http.get(this.baseUrl+'/categories/');
    
  }
}
