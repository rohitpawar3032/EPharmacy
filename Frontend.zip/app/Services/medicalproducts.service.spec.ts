import { TestBed } from '@angular/core/testing';

import { MedicalproductsService } from './medicalproducts.service';

describe('MedicalproductsService', () => {
  let service: MedicalproductsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MedicalproductsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
