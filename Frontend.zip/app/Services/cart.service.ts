import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Cart } from '../models/cart.model';
import { OrderDetails } from '../models/orderDetails';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  // url = 'http://localhost:8181/medicalitems/'
  //   url1 ='http://localhost:8181/orderdetails/'

  //   constructor(private httpClient: HttpClient) { }
    

  //   getCart(): Observable<any>
  //   {
  //       return this.httpClient.get(this.url1)
  //   }


  //   postInCart(order: OrderDetails): Observable<Object>
  //   {

  //       return this.httpClient.post(this.url1,order)
  //   }


  //   deleteOrder(id: number): Observable<any> {
  //     console.log(".....");
  //     console.log(this.url1+id)
  //     return this.httpClient.delete(this.url1+id);
  //   }
  cartChanged = new Subject<Cart[]>();
  cart_list: Cart[] = [];

  getCart() {
    return this.cart_list.slice();
  }
  addToCart(cart_item: Cart) {
    let flag = false;
    for (let item of this.cart_list) {
      if (item.item.id == cart_item.item.id) {
        flag = true;
        item.amount = item.amount + 1;
      }
    }
    if (flag == false)
      this.cart_list.push(cart_item);

    this.cartChanged.next(this.cart_list.slice());
  }
  deleteItem(index: number) {
    // for (let item of this.cart_list) {
    //   if (item.i tem.id == id) {
    //     this.cart_list.splice(id, 1);
    //     break;
    //   }
   // }
   this.cart_list.splice(index,1)
    this.cartChanged.next(this.cart_list.slice());
  }



}
