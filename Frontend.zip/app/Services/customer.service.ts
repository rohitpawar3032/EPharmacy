import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../models/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  baseUrl = 'http://localhost:8181'   //express port 4000

  constructor(private http: HttpClient) { }

  getCustomer(id: number): Observable<any> {

    console.log(".....");
    return this.http.get(this.baseUrl+'/customers/'+id);
  }

  createCustomer(customer: Object): Observable<Object> {
    console.log(customer);
        return this.http.post(this.baseUrl+'/customers/', customer);
  }

  updateCustomer(customer: Customer): Observable<Object> {
    console.log(customer.customerId);
    return this.http.put(this.baseUrl+'/customers/'+customer.customerId,customer);
  }

  deleteCustomer(id: number): Observable<any> {
    console.log(".....");
    console.log(this.baseUrl+'/customers/'+id)
    return this.http.delete<boolean>(this.baseUrl+'/customers/'+id);
  }

  getCustomerList(): Observable<any> {
    console.log(this.baseUrl+'/customers/');
    return this.http.get(this.baseUrl+'/customers/');
    
  }
}
