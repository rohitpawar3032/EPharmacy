import { Injectable, ɵConsole } from '@angular/core';
import {MedicalProduct} from '../models/medicalproduct.model';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MedicalproductsService {
  private baseUrl = 'http://localhost:8181';

  constructor(private http: HttpClient) { }

  getProduct(id: number): Observable<any> {

    console.log(".....");
    return this.http.get(this.baseUrl+'/medicalitems/id/'+id);
  }

  createProduct(product: Object): Observable<Object> {
    console.log(product);
        return this.http.post(this.baseUrl+'/medicalitems/', product);
  }

  updateProduct(product: MedicalProduct): Observable<Object> {
    console.log(product.id);
    return this.http.put(this.baseUrl+'/medicalitems/'+product.id,product);
  }

  deleteProduct(id: number): Observable<any> {
    console.log(".....");
    console.log(this.baseUrl+'/medicalitems/'+id)
    return this.http.delete<boolean>(this.baseUrl+'/medicalitems/'+id);
  }

  getProductsList(): Observable<any> {
    console.log(this.baseUrl+'/medicalitems/');
    return this.http.get(this.baseUrl+'/medicalitems/');
    
  }
  getProductByName(name: string): Observable<any> {

    console.log(".....");
    return this.http.get(this.baseUrl+'/medicalitems/name/'+name);
  }
}


