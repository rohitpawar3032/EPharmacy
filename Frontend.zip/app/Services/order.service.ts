import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  baseUrl = 'http://localhost:8181'   //express port 4000

  constructor(private http: HttpClient) { }

  getOrder(id: number): Observable<any> {

    console.log(".....");
    return this.http.get(this.baseUrl+'/orders/'+id);
  }

  addOrder(customer: Object): Observable<Object> {
    console.log(customer);
        return this.http.post(this.baseUrl+'/orders/', customer);
  }

  deleteOrder(id: number): Observable<any> {
    console.log(".....");
    console.log(this.baseUrl+'/orders/'+id)
    return this.http.delete<boolean>(this.baseUrl+'/orders/'+id);
  }

  getOrderList(): Observable<any> {
    console.log(this.baseUrl+'/orders/');
    return this.http.get(this.baseUrl+'/orders/');
    
  }
  
}
