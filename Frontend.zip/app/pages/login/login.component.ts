import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { CustomerService } from 'src/app/Services/customer.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{

  email = ''
    password = ''
    rememberme = false
    ispharmacyManager:boolean
    id:any

    constructor(private router: Router,
        private authService: AuthService) { }
        ngOnInit(): void {
        }
      
    onlogin()
    {
        if(this.email.length == 0)
        {
            alert('email field can not be empty')
        }
        else if(this.password.length == 0)
        {
            alert('password can not be empty')
        }
        else {
          this.authService
            .login(this.email, this.password)
            .subscribe(response => {
              console.log(response);
              this.ispharmacyManager=response['pharmacyManager']
              console.log(response['customerId']);
              console.log(response['pharmacyManager']);
              this.id=response['customerId']
              if(this.ispharmacyManager)
              {
                sessionStorage.setItem("admId",this.id)
                this.router.navigate(['/admin'])
              }
              else{
                sessionStorage.setItem("custId",this.id)
                 sessionStorage.setItem("firstName",response['firstName'])
                // sessionStorage.setItem("flag",'0')
              
              this.router.navigate(['/home'])
              }
              
                error =>   alert(response['error'])
              
            })

         
        }

    }

}
