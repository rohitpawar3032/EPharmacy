import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductCategory } from 'src/app/models/category';
import { MedicalProduct } from 'src/app/models/medicalproduct.model';
import { MedicalproductsService } from 'src/app/Services/medicalproducts.service';

@Component({
  selector: 'app-create-product',
  templateUrl: './create-product.component.html',
  styleUrls: ['./create-product.component.css']
})
export class CreateProductComponent implements OnInit {
product:MedicalProduct
  constructor(private productService: MedicalproductsService, private router: Router) {

    this.product= new MedicalProduct();
this.product.category=new ProductCategory();

   }

  
  
  submitted 

  ngOnInit() {
  }

  saveProduct() {
    this.productService.createProduct(this.product)
      .subscribe(data => console.log(data), error => console.log(error));
    this.product = new MedicalProduct();
    this.gotoProductList();
  }

  onSubmit() {
    this.saveProduct();    
  }

  gotoProductList() {
    this.router.navigate(['/medicalitems']);
  }

}
