import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MedicalProduct } from 'src/app/models/medicalproduct.model';
import { MedicalproductsService } from 'src/app/Services/medicalproducts.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  custId:any
  products: Observable<MedicalProduct[]>;

  constructor(private productService: MedicalproductsService, private router: Router) { }

  ngOnInit() {
    this.fetchProductList();
    this.custId= sessionStorage.getItem("custId");
    
  }

  fetchProductList() {
  
    this.products = this.productService.getProductsList();
    console.log(this.products);
  }

  productDetails(id: number) {
    this.router.navigate(['details', id]);
  }
}
