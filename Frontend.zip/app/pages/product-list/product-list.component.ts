import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MedicalProduct } from 'src/app/models/medicalproduct.model';
import { MedicalproductsService } from 'src/app/Services/medicalproducts.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  products: Observable<MedicalProduct[]>;
  constructor(private productService: MedicalproductsService, private router: Router) { }

  ngOnInit() {
    this.fetchProductList();
    console.log(this.products+"..........");
  }

  fetchProductList() {
    
    this.products = this.productService.getProductsList();
  }

  deleteProduct(id: number) {
    console.log(".....");
    this.productService.deleteProduct(id)
      .subscribe(
        data => {
          console.log(".....");
          console.log(data);
          console.log(".....");
          console.log("subscribe");
          this.fetchProductList();
          console.log(".....");
        },
        error =>  this.fetchProductList());
  }

  productDetails(id: number) {
    this.router.navigate(['details', id]);
  }

  updateProduct(product: MedicalProduct){
    this.router.navigate(['update', product]);
  }

}
