import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { observable, Observable, Subscription } from 'rxjs';
import { Cart } from 'src/app/models/cart.model';
import { OrderDetails } from 'src/app/models/orderDetails';
import { CartService } from 'src/app/Services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  // ngOnInit(): void {

  //   if(sessionStorage.getItem("custId"))
  //   {
  //     this.loadProduct()
  //   }
    
  // }

  // Cart:Observable<OrderDetails>;
  //   TotalAmountOfProduct:number = 0;
  //   msg:String
  //   id = sessionStorage.getItem('custId')
  //   empty: boolean
    
  //   constructor(private service:CartService,
  //       private activateRoute:ActivatedRoute,
  //       private route:Router) {
      
         
  //       this.loadProduct()

  //    }

  //   loadProduct()
  //   {
  //       this.service.getCart().subscribe(response =>{
  //               this.Cart = response
               
  //             console.log(this.Cart)
          
  //                   this.msg = 'your items list'
  //                   this.empty = false
  //       })
  //   }
  //   deleteProduct(id: number) {
  //     console.log("delete");
  //     this.service.deleteOrder(id)
  //       .subscribe(
  //         data => {
  //           console.log(".....");
  //           console.log(data);
  //           console.log(".....");
  //           console.log("subscribe");
  //           console.log(".....");
  //         }),
  //         error =>  "";
  //   }

  private subscription: Subscription;
  public cart_list: Cart[];
  grand_total=0;
  constructor(private cartService: CartService, private router: Router) {
    this.cart_list = this.cartService.getCart();
    this.getGrandTotal();
   }

  ngOnInit(): void {
    this.subscription = this.cartService.cartChanged.subscribe((carts) => {
      this.cart_list = carts;
      this.grand_total=0;
      this.getGrandTotal();

    });
  }
  onDeleteItem(index: number){
    this.cartService.deleteItem(index);
  }
  // ngOnDestroy() {
  //   this.subscription.unsubscribe();
  // }
  getGrandTotal(){
      for(let item of this.cart_list)
      {
        this.grand_total = this.grand_total + (item.amount * item.item.unitPrice);
      }

  }

  userOrder()
  {
    this.router.navigate(['userorder']);
  }



}
