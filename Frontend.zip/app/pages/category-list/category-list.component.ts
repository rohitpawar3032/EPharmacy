import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ProductCategory } from 'src/app/models/category';
import { ProductCategoryService } from 'src/app/Services/product-category.service';

@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css']
})
export class CategoryListComponent implements OnInit {

  categories: Observable<ProductCategory[]>;

  constructor(private categoryService: ProductCategoryService, private router: Router) { }

  ngOnInit() {
    this.fetchCategoryList();
  }

  fetchCategoryList() {
    
    this.categories = this.categoryService.getCategoryList();
  }

  deleteCategory(id: number) {
    console.log(".....");
    this.categories
      .subscribe(
        data => {
          console.log(".....");
          console.log(data);
          console.log(".....");
          console.log("subscribe");
          this.fetchCategoryList();
          console.log(".....");
        },
        error =>  this.fetchCategoryList());
  }

  productDetails(id: number) {
    this.router.navigate(['details', id]);
  }

  updateCategory(categories: ProductCategory){
    this.router.navigate(['update', categories]);
  }

}
