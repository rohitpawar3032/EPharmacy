import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MedicalProduct } from 'src/app/models/medicalproduct.model';
import { MedicalproductsService } from 'src/app/Services/medicalproducts.service';

@Component({
  selector: 'app-product-update',
  templateUrl: './product-update.component.html',
  styleUrls: ['./product-update.component.css']
})
export class ProductUpdateComponent implements OnInit {

  id: number;
  product: MedicalProduct;

  constructor(private route: ActivatedRoute,private router: Router,
    private productService: MedicalproductsService) { }

  ngOnInit() {
    this.product = new MedicalProduct();

    this.id = this.route.snapshot.params['id'];
    
    this.productService.getProduct(this.id)
      .subscribe(data => {
        console.log(data)
        this.product = data;
      }, error => console.log(error));
  }

  updateProduct() {
    this.productService.updateProduct(this.product)
      .subscribe(data => console.log(data), error => console.log());
    this.product = new MedicalProduct();
    console.log(this.product.category);
    this.gotoList();
  }

  onSubmit() {
    console.log("update"+this.product.id);
    this.updateProduct();    
  }

  gotoList() {
    this.router.navigate(['/medicalitems']);
  }
}
