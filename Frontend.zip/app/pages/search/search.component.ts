import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MedicalProduct } from 'src/app/models/medicalproduct.model';
import { MedicalproductsService } from 'src/app/Services/medicalproducts.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  constructor(private productService: MedicalproductsService, private router: Router) { }
  products: Observable<MedicalProduct[]>;
  search:string=localStorage.getItem("search")

  ngOnInit() {
    this.fetchProductList();
    console.log(this.products+this.search);
  }
  fetchProductList() {
    this.products = this.productService.getProductByName(this.search)
  }


  productDetails(id: number) {
    this.router.navigate(['details', id]);
  }
}
