import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from 'src/app/models/customer';
import { CustomerService } from 'src/app/Services/customer.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
customer:Customer
cid:string
custId:number

  constructor(private route: ActivatedRoute, private router: Router,
    private customerService: CustomerService) { }


  ngOnInit() {
    this.customer = new Customer();
   
    this.cid=sessionStorage.getItem("custId");
    this.custId=parseInt(this.cid);
    console.log(this.custId)

    this.customerService.getCustomer(this.custId)
      .subscribe(data => {
        console.log(data)
        this.customer = data;
      }, error => console.log(error));

      console.log(this.customer.customerId);
  }

}
