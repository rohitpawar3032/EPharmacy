import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ProductCategory } from 'src/app/models/category';
import { Customer } from 'src/app/models/customer';
import { MedicalProduct } from 'src/app/models/medicalproduct.model';
import { CustomerService } from 'src/app/Services/customer.service';
import { MedicalproductsService } from 'src/app/Services/medicalproducts.service';
import { ProductCategoryService } from 'src/app/Services/product-category.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  products: Observable<MedicalProduct[]>;
  categories: Observable<ProductCategory[]>;
  customers: Observable<Customer[]>;

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  onlogout()
    {
      sessionStorage.removeItem("admId");
       this.router.navigate(['/home'])
    }


    showproduct()
    {
      this.router.navigate(['medicalitems'])
    }

    showorder()
    {
      this.router.navigate(['orderlist'])
    }

    showcustomer()
    {
      this.router.navigate(['customer'])
    }

    addItem()
    {
      this.router.navigate(['add'])
    }

}
