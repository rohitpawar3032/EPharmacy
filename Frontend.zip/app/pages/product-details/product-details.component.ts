import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Cart } from 'src/app/models/cart.model';
import { Customer } from 'src/app/models/customer';
import { MedicalProduct } from 'src/app/models/medicalproduct.model';
import { OrderDetails } from 'src/app/models/orderDetails';
import { CartService } from 'src/app/Services/cart.service';
import { MedicalproductsService } from 'src/app/Services/medicalproducts.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  
  rate: number=0
  temp: number
  count: number = 0;
  id: number;
  product: MedicalProduct;
  custId:number=0;
  cid:any="";

  order: OrderDetails = new OrderDetails();
   
  constructor(private route: ActivatedRoute, private router: Router,
    private productService: MedicalproductsService,private cartservice:CartService) {
      this.order.customer=new Customer();
      this.order.product=new MedicalProduct();
     }

  ngOnInit() {
    this.product = new MedicalProduct();
   
    this.cid=sessionStorage.getItem("custId");
    this.custId=parseInt(this.cid);
    console.log(this.custId)


    this.id = this.route.snapshot.params['id'];

    this.productService.getProduct(this.id)
      .subscribe(data => {
        console.log(data)
        this.product = data;
      }, error => console.log(error));

      console.log(this.product.id);
  }

  list() {
    this.router.navigate(['medicalitems']);
  }

  // addToCart() {
  //   console.log(this.product.id);
  //   if(this.custId >= 1)
  //   { 
  //     this.order.orderQuantity=this.count
  //     this.order.totalPrice=this.rate
  //     this.order.product.id=this.product.id
  //     this.order.customer.customerId=JSON.parse(sessionStorage.getItem("custId"));
  //     this.cartservice.postInCart(this.order)
  //     .subscribe(data =>{ console.log(data)
  //     console.log(this.order)}),
  //      error => console.log(error);
  //   this.order = new OrderDetails();
  
  //     this.router.navigate(['cart']);
  //   }
  //   else{
  //   this.router.navigate(['login']);
  //   }
  // }
  addToCart(){
    if(this.custId >= 1)
     { 
    this.count = this.count+1;
    const  cart_item = new Cart(this.product, this.count);
    this.cartservice.addToCart(cart_item);

    //this._snackBar.open("Product Added","successfylly!",{ duration:1000});
    console.log(cart_item);
    this.router.navigate(['cart']);
  }
    else{
    this.router.navigate(['login']);
    }
  }

  OnIncrement()
  {
     this.count = this.count + 1
     this.rate = this.product.unitPrice * this.count
  }

  OnDecrement()
  {
     if(this.count == 0)
     {
         alert('Can not decrement')
     }
     else
     {
         this.count = this.count -1
         this.rate = this.product.unitPrice * this.count
     }
  }


}
